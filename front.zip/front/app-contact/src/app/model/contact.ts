export interface Contacts {
    id?: string;
    name?: string;
    email?: string;
    phone?: string;
    creationDate?: Date;
    address?: string;
    status?: string;
}