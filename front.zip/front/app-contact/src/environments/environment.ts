export const environment = {
    production: false,
    API_URL: 'YOUR URL TO MODIFY'
};
